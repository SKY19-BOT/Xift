const MOODS = [
  { id: 'happy', label: 'Happy', icon: 'Sun', emoji: '😊' },
  { id: 'focused', label: 'Focused', icon: 'Target', emoji: '🎯' },
  { id: 'stressed', label: 'Stressed', icon: 'Zap', emoji: '😰' },
  { id: 'tired', label: 'Tired', icon: 'Moon', emoji: '😴' },
  { id: 'energetic', label: 'Energetic', icon: 'Coffee', emoji: '⚡' }
];

const TIME_OPTIONS = [
  { id: '15min', label: '15 minutes', value: 15 },
  { id: '30min', label: '30 minutes', value: 30 },
  { id: '1hour', label: '1 hour', value: 60 },
  { id: '2hours', label: '2+ hours', value: 120 }
];

const PART_OF_DAY_OPTIONS = [
  { id: 'morning', label: 'Morning' },
  { id: 'afternoon', label: 'Afternoon' },
  { id: 'evening', label: 'Evening' },
  { id: 'night', label: 'Night' }
];

const LOGO_URL = "https://storage.googleapis.com/hostinger-horizons-assets-prod/1ff7a730-b2ae-47ef-b88c-2edd69b44970/6c7acbb2647198cd6c5c113d5f80adf0.png";

export { MOODS, TIME_OPTIONS, PART_OF_DAY_OPTIONS, LOGO_URL };