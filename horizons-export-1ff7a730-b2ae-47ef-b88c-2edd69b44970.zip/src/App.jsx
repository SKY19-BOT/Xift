import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { CheckCircle, Moon as MoonIcon, Sun as SunIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';

import MoodSelection from '@/components/MoodSelection';
import TimeSelection from '@/components/TimeSelection';
import CustomTaskInput from '@/components/CustomTaskInput';
import ResultsDisplay from '@/components/ResultsDisplay';
import AiChatbot from '@/components/AiChatbot';

import { MOODS, TIME_OPTIONS, PART_OF_DAY_OPTIONS, LOGO_URL } from '@/constants';

const moodThemes = {
  happy: 'theme-happy',
  focused: 'theme-focused',
  stressed: 'theme-stressed',
  tired: 'theme-tired',
  energetic: 'theme-energetic',
  custom: 'theme-custom',
  default: 'theme-default',
};

function App() {
  const [currentStep, setCurrentStep] = useState('mood');
  const [selectedMood, setSelectedMood] = useState(null);
  const [customMoodInput, setCustomMoodInput] = useState('');
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [selectedTime, setSelectedTime] = useState(null); // e.g. '30min'
  const [customTimeInput, setCustomTimeInput] = useState(''); // e.g. '45' (minutes)
  const [selectedPartOfDay, setSelectedPartOfDay] = useState(null);
  const [customTasks, setCustomTasks] = useState('');
  const [suggestions, setSuggestions] = useState([]); 
  const [completedTaskStats, setCompletedTaskStats] = useState([]); 
  const [currentSessionCompletedIndices, setCurrentSessionCompletedIndices] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showChatbot, setShowChatbot] = useState(false);
  const [chatbotTask, setChatbotTask] = useState('');
  const [chatbotMessages, setChatbotMessages] = useState([]);
  const [theme, setTheme] = useState('dark'); // 'light' or 'dark'
  const [currentMoodTheme, setCurrentMoodTheme] = useState(moodThemes.default);
  const [timeProgress, setTimeProgress] = useState(0);

  const { toast } = useToast();
  const recognitionRef = useRef(null);

  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
  }, [theme]);

  useEffect(() => {
    Object.values(moodThemes).forEach(cls => document.body.classList.remove(cls));
    document.body.classList.add(currentMoodTheme);
  }, [currentMoodTheme]);

  useEffect(() => {
    if (selectedMood) {
      setCurrentMoodTheme(moodThemes[selectedMood] || moodThemes.custom);
    } else {
      setCurrentMoodTheme(moodThemes.default);
    }
  }, [selectedMood]);


  useEffect(() => {
    const saved = localStorage.getItem('xift-data');
    if (saved) {
      const data = JSON.parse(saved);
      setCompletedTaskStats(data.completedTaskStats || []);
      if (data.theme) setTheme(data.theme);
    }
  }, []);
  
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("Speech recognition not supported by this browser.");
      return;
    }

    const instance = new SpeechRecognition();
    instance.continuous = true; // Keep listening for longer phrases
    instance.interimResults = true; // Get results as user speaks
    instance.lang = 'en-US';

    instance.onresult = (event) => {
      let finalTranscript = '';
      let interimTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      setVoiceTranscript(interimTranscript || finalTranscript); // Show interim results
      if (finalTranscript) {
        setCustomMoodInput(finalTranscript.trim());
        setSelectedMood('custom'); 
        // No toast here, let user confirm or stop listening
      }
    };

    instance.onerror = (event) => {
      console.error("Speech recognition error", event.error);
      setIsListening(false);
      setVoiceTranscript('');
      let errorMessage = "Could not recognize speech. Please try again or type your mood.";
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        errorMessage = "Microphone access denied. Please allow microphone access in your browser settings.";
      } else if (event.error === 'no-speech' && !voiceTranscript) { // only show if nothing was captured
        errorMessage = "No speech detected. Please try speaking more clearly.";
      }
      toast({ title: "Voice Input Error", description: errorMessage, variant: "destructive" });
    };
    
    instance.onend = () => {
      setIsListening(false);
      if (voiceTranscript) { // If something was transcribed
        setCustomMoodInput(voiceTranscript.trim());
        setSelectedMood('custom');
        toast({ title: "Voice Input Captured!", description: `Mood set to: "${voiceTranscript.trim()}"` });
      }
      setVoiceTranscript(''); // Clear for next use
    };
    
    recognitionRef.current = instance;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [toast]); // Removed voiceTranscript from dependencies to avoid re-triggering on every interim result

  const handleListen = () => {
    if (!recognitionRef.current) {
       toast({ title: "Feature Not Ready", description: "Speech recognition is initializing. Try again in a moment.", variant: "destructive" });
      return;
    }
    if (isListening) {
      recognitionRef.current.stop(); // This will trigger onend
      setIsListening(false);
    } else {
      try {
        setCustomMoodInput(''); // Clear previous text input
        setVoiceTranscript(''); // Clear previous voice transcript
        recognitionRef.current.start();
        setIsListening(true);
        toast({ title: "Listening...", description: "Speak your mood clearly. Click mic again to stop." });
      } catch (e) {
         console.error("Error starting speech recognition:", e);
         toast({ title: "Error", description: "Could not start voice input. Check permissions and try again.", variant: "destructive"});
         setIsListening(false); 
      }
    }
  };

  const saveToStorage = (data) => {
    localStorage.setItem('xift-data', JSON.stringify(data));
  };

  const getMoodLabel = () => {
    if (selectedMood === 'custom' && customMoodInput.trim()) {
      return customMoodInput;
    }
    return MOODS.find(m => m.id === selectedMood)?.label || 'Selected';
  };

  const getTimeInMinutes = () => {
    if (customTimeInput.trim() && parseInt(customTimeInput) > 0) {
      return parseInt(customTimeInput);
    }
    return TIME_OPTIONS.find(t => t.id === selectedTime)?.value || 0;
  }
  
  const getTimeLabel = () => {
    const minutes = getTimeInMinutes();
    if (minutes > 0) return `${minutes} minutes`;
    return TIME_OPTIONS.find(t => t.id === selectedTime)?.label || 'Selected time';
  }

  useEffect(() => {
    const totalTime = getTimeInMinutes();
    if (totalTime > 0 && suggestions.length > 0) {
      // Simplified: assume each task takes an equal fraction of time for progress
      const completedTasksInSession = currentSessionCompletedIndices.length;
      const progress = (completedTasksInSession / suggestions.length) * 100;
      setTimeProgress(Math.min(progress, 100));
    } else {
      setTimeProgress(0);
    }
  }, [currentSessionCompletedIndices, suggestions, selectedTime, customTimeInput]);


  const generateSuggestions = async () => {
    setIsGenerating(true);
    setCurrentSessionCompletedIndices([]);
    setTimeProgress(0);
    
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    
    const moodLabel = getMoodLabel();
    let timeValue = getTimeInMinutes();
    if (timeValue <= 0) timeValue = 30; 

    let baseSuggestions = [];
    if (moodLabel.toLowerCase().includes('happy') && timeValue <= 30) baseSuggestions = ['Quick 5-min meditation', 'Listen to a happy song', 'Jot down 3 things you are grateful for'];
    else if (moodLabel.toLowerCase().includes('focus') && timeValue >= 60) baseSuggestions = ['Deep work block: Project X', 'Learn a new concept for 45 mins', 'Plan your next 3 steps for a major goal'];
    else if (moodLabel.toLowerCase().includes('stress')) baseSuggestions = ['5 min breathing exercise', 'Short walk (10 mins)', 'Write down your worries'];
    else if (moodLabel.toLowerCase().includes('tired') && timeValue <= 30) baseSuggestions = ['Power nap (20 mins)', 'Gentle stretching', 'Hydrate and rest'];
    else if (moodLabel.toLowerCase().includes('energetic')) baseSuggestions = ['Quick HIIT workout', 'Tackle 3 small tasks', 'Brainstorm ideas for a new project'];
    else baseSuggestions = ['Review your to-do list', 'Read an inspiring article', 'Drink a glass of water'];
    
    if (selectedPartOfDay === 'morning') baseSuggestions.push('Plan your day\'s top 3 priorities');
    else if (selectedPartOfDay === 'evening') baseSuggestions.push('Reflect on your day and achievements');

    const customList = customTasks.trim() ? customTasks.split('\n').filter(task => task.trim()) : [];
    const allSuggestions = [...customList, ...baseSuggestions];
    
    setSuggestions(allSuggestions.slice(0, 5).map((text, index) => ({ text, id: `sugg-${index}-${Date.now()}` })));
    setCurrentStep('results');
    setIsGenerating(false);
    
    toast({
      title: "AI Suggestions Ready! 🎯",
      description: `Generated ${allSuggestions.slice(0,5).length} tasks for your ${moodLabel.toLowerCase()} mood and ${timeValue} mins.`
    });
  };

  const handleCompleteTask = (suggestionIndex) => {
    const taskToComplete = suggestions[suggestionIndex];
    if (!taskToComplete || currentSessionCompletedIndices.includes(suggestionIndex)) return;

    const newCompletedStat = {
      taskText: taskToComplete.text,
      mood: getMoodLabel(),
      completedAt: new Date().toISOString(),
      id: `comp-${taskToComplete.id}-${Date.now()}`
    };
    
    const updatedCompletedTaskStats = [...completedTaskStats, newCompletedStat];
    setCompletedTaskStats(updatedCompletedTaskStats);
    saveToStorage({ completedTaskStats: updatedCompletedTaskStats, theme });
    setCurrentSessionCompletedIndices(prev => [...prev, suggestionIndex]);
    
    toast({
      title: "✔ Task Completed!",
      description: `"${taskToComplete.text}" is done. Awesome!`,
      variant: 'default',
      duration: 3000,
    });

    const taskTextLower = taskToComplete.text.toLowerCase();
    if (taskTextLower.includes("plan") || taskTextLower.includes("write") || taskTextLower.includes("list") || taskTextLower.includes("brainstorm")) {
        setChatbotTask(taskToComplete.text);
        setChatbotMessages([{sender: 'ai', text: `Great job completing "${taskToComplete.text}"! Did you want to elaborate or save any notes related to it here?`}]);
        setShowChatbot(true);
    }
  };
  
  const handleChatbotSendMessage = async (currentMessages) => {
    const lastUserMessage = currentMessages.findLast(m => m.sender === 'user');
    if (!lastUserMessage) return "I'm listening!";
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000)); 
    if (lastUserMessage.text.toLowerCase().includes("thanks") || lastUserMessage.text.toLowerCase().includes("done")) {
        return "You're welcome! Feel free to ask if anything else comes up.";
    }
    return `Okay, I've noted that about "${chatbotTask}". Anything else I can help with regarding this?`;
  };

  const resetFlow = () => {
    setCurrentStep('mood');
    setSelectedMood(null);
    setCustomMoodInput('');
    setVoiceTranscript('');
    setSelectedTime(null);
    setCustomTimeInput('');
    setSelectedPartOfDay(null);
    setCustomTasks('');
    setSuggestions([]);
    setCurrentSessionCompletedIndices([]);
    setShowChatbot(false);
    setChatbotMessages([]);
    setTimeProgress(0);
    setCurrentMoodTheme(moodThemes.default);
  };

  const handleNextToTime = () => {
    if (!selectedMood) { toast({ title: "Select a Mood", description: "Please select or define your mood first.", variant: "destructive"}); return; }
    if (selectedMood === 'custom' && !customMoodInput.trim()) { toast({ title: "Define Your Mood", description: "Please type or speak your custom mood.", variant: "destructive"}); return; }
    setCurrentStep('time');
  };

  const handleNextToCustomTasks = () => {
    let timeIsValid = (selectedTime || (customTimeInput.trim() && parseInt(customTimeInput) > 0));
    if (!timeIsValid) { toast({ title: "Select or Enter Time", description: "Please select a preset time or enter a valid custom time in minutes.", variant: "destructive"}); return; }
    if (!selectedPartOfDay) { toast({ title: "Select Part of Day", description: "Please choose the part of day.", variant: "destructive"}); return; }
    setCurrentStep('custom');
  };

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    saveToStorage({ completedTaskStats, theme: newTheme });
  };

  return (
    <div className={`min-h-screen relative overflow-hidden transition-colors duration-500 ${theme === 'light' ? 'bg-slate-100' : 'bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900'}`}>
      <div className={`absolute inset-0 overflow-hidden transition-opacity duration-500 ${theme === 'light' ? 'opacity-30' : 'opacity-100'}`}>
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 floating-animation"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 floating-animation" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-10 floating-animation" style={{animationDelay: '4s'}}></div>
      </div>

      <div className="absolute top-4 right-4 z-20">
        <div className="flex items-center space-x-2 p-2 glass-effect rounded-lg">
          <SunIcon className={`w-5 h-5 ${theme === 'light' ? 'text-yellow-500' : 'text-gray-400'}`} />
          <Switch
            checked={theme === 'dark'}
            onCheckedChange={toggleTheme}
            aria-label="Toggle dark mode"
          />
          <MoonIcon className={`w-5 h-5 ${theme === 'dark' ? 'text-purple-400' : 'text-gray-400'}`} />
        </div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12 pt-12"
        >
          <div className="flex items-center justify-center mb-4">
            <img src={LOGO_URL} alt="Xift Logo" className="w-16 h-16 mr-3" />
            <h1 className={`text-5xl font-bold ${theme === 'dark' ? 'gradient-text' : 'text-slate-800'}`}>Xift</h1>
          </div>
          <p className={`text-xl ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'} max-w-2xl mx-auto`}>
            AI-powered productivity that adapts to your mood and time ✨
          </p>
          {completedTaskStats.length > 0 && (
            <div className={`mt-4 inline-flex items-center px-4 py-2 ${theme === 'dark' ? 'bg-green-500/20' : 'bg-green-100'} rounded-full`}>
              <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
              <span className={`${theme === 'dark' ? 'text-green-300' : 'text-green-700'}`}>{completedTaskStats.length} lifetime tasks completed!</span>
            </div>
          )}
        </motion.div>

        {currentStep === 'results' && suggestions.length > 0 && (
          <motion.div 
            initial={{opacity: 0}} animate={{opacity:1}}
            className="max-w-md mx-auto mb-8 px-2">
            <label htmlFor="time-progress" className={`block text-sm font-medium mb-1 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>Session Progress</label>
            <Progress id="time-progress" value={timeProgress} className="w-full" />
            <p className={`text-xs text-center mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>{Math.round(timeProgress)}% of suggested tasks time</p>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {currentStep === 'mood' && (
            <MoodSelection 
              selectedMood={selectedMood}
              customMoodInput={customMoodInput}
              voiceTranscript={voiceTranscript}
              isListening={isListening}
              onMoodSelect={(moodId) => { setSelectedMood(moodId); if (moodId !== 'custom') {setCustomMoodInput(''); setVoiceTranscript('');} }}
              onCustomMoodInput={(value) => { setCustomMoodInput(value); setSelectedMood('custom'); setVoiceTranscript(''); }}
              onListen={handleListen}
              onNext={handleNextToTime}
              theme={theme}
            />
          )}

          {currentStep === 'time' && (
            <TimeSelection
              selectedTime={selectedTime}
              customTimeInput={customTimeInput}
              selectedPartOfDay={selectedPartOfDay}
              onTimeSelect={(timeId) => { setSelectedTime(timeId); setCustomTimeInput('');}}
              onCustomTimeInput={(value) => { setCustomTimeInput(value); setSelectedTime(null);}}
              onPartOfDaySelect={setSelectedPartOfDay}
              onNext={handleNextToCustomTasks}
              onSkip={generateSuggestions}
              theme={theme}
            />
          )}

          {currentStep === 'custom' && (
            <CustomTaskInput
              customTasks={customTasks}
              onCustomTasksChange={setCustomTasks}
              onGenerate={generateSuggestions}
              isGenerating={isGenerating}
              theme={theme}
            />
          )}

          {currentStep === 'results' && (
            <ResultsDisplay
              moodLabel={getMoodLabel()}
              timeLabel={getTimeLabel()}
              partOfDayLabel={PART_OF_DAY_OPTIONS.find(p => p.id === selectedPartOfDay)?.label}
              suggestions={suggestions}
              onCompleteTask={handleCompleteTask}
              onReset={resetFlow}
              completedSuggestionIndices={currentSessionCompletedIndices}
              theme={theme}
            />
          )}
        </AnimatePresence>
      </div>
      
      <AnimatePresence>
        {showChatbot && 
          <AiChatbot 
            task={chatbotTask} 
            onClose={() => setShowChatbot(false)}
            initialMessages={chatbotMessages}
            onSendMessage={handleChatbotSendMessage}
            theme={theme}
          />}
      </AnimatePresence>
      <Toaster />
    </div>
  );
}

export default App;