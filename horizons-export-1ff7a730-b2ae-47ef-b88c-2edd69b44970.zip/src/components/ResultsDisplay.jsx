import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, CheckCircle } from 'lucide-react';

const ResultsDisplay = ({ moodLabel, timeLabel, partOfDayLabel, suggestions, onCompleteTask, onReset, completedSuggestionIndices, theme }) => {
  const cardBaseClass = theme === 'dark' ? 'glass-effect' : 'bg-white/70 shadow-lg border border-slate-200';
  const cardHoverClass = theme === 'dark' ? 'hover:bg-white/20' : 'hover:bg-slate-50';
  const completedCardClass = theme === 'dark' ? 'bg-green-500/30' : 'bg-green-100/70 border-green-300';
  const textColor = theme === 'dark' ? 'text-white' : 'text-slate-800';
  const subTextColor = theme === 'dark' ? 'text-gray-400' : 'text-gray-600';
  const buttonOutlineClass = theme === 'dark' ? 'border-white/30 text-white hover:bg-white/10' : 'border-slate-400 text-slate-700 hover:bg-slate-100';

  return (
    <motion.div
      key="results"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-4xl mx-auto"
    >
      <div className="text-center mb-8">
        <h2 className={`text-3xl font-bold ${textColor} mb-4`}>Your Personalized Productivity Plan</h2>
        <p className={`${subTextColor}`}>AI-curated tasks for your {moodLabel.toLowerCase()} mood, {timeLabel} during the {partOfDayLabel?.toLowerCase()}</p>
      </div>
      
      {suggestions.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <AnimatePresence>
            {suggestions.map((suggestion, index) => {
              const isCompleted = completedSuggestionIndices.includes(index);
              return (
                <motion.div
                  key={suggestion.id} 
                  layout
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                  transition={{ delay: index * 0.05, type: "spring", stiffness: 300, damping: 25 }}
                  className={`rounded-xl p-6 transition-all duration-300 
                              ${isCompleted ? completedCardClass : `${cardBaseClass} ${cardHoverClass}`}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <motion.p 
                        className={`${textColor} text-lg mb-3 ${isCompleted ? 'line-through opacity-70' : ''}`}
                        animate={{ textDecorationLine: isCompleted ? 'line-through' : 'none' }}
                        transition={{ duration: 0.3 }}
                      >
                        {suggestion.text}
                      </motion.p>
                      <Button
                        onClick={() => onCompleteTask(index)}
                        size="sm"
                        className={`${isCompleted ? 
                                      (theme === 'dark' ? 'bg-gray-500 hover:bg-gray-600' : 'bg-gray-400 hover:bg-gray-500') : 
                                      (theme === 'dark' ? 'bg-green-600 hover:bg-green-700' : 'bg-green-500 hover:bg-green-600')} 
                                    text-white`}
                        disabled={isCompleted}
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        {isCompleted ? 'Completed' : 'Complete'}
                      </Button>
                    </div>
                    {!isCompleted && <Sparkles className={`w-6 h-6 ${theme === 'dark' ? 'text-purple-400' : 'text-purple-500'} ml-4 flex-shrink-0`} />}
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      ) : (
        <p className={`text-center ${subTextColor} text-lg mb-8`}>No suggestions generated. Try adjusting your inputs!</p>
      )}
      
      <div className="text-center">
        <Button 
          onClick={onReset}
          variant="outline"
          className={`${buttonOutlineClass} px-8 py-3`}
        >
          Start New Session
        </Button>
      </div>
    </motion.div>
  );
};

export default ResultsDisplay;