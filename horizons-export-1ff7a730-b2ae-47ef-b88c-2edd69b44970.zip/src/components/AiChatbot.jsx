import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X as LucideX, Send } from 'lucide-react';

const TypingIndicator = ({ theme }) => (
  <motion.div 
    className="flex items-center space-x-1 p-2"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
  >
    <motion.div
      className={`w-2 h-2 ${theme === 'dark' ? 'bg-purple-400' : 'bg-purple-600'} rounded-full`}
      animate={{ y: [0, -3, 0] }}
      transition={{ duration: 0.8, repeat: Infinity, ease: "easeInOut" }}
    />
    <motion.div
      className={`w-2 h-2 ${theme === 'dark' ? 'bg-purple-400' : 'bg-purple-600'} rounded-full`}
      animate={{ y: [0, -3, 0] }}
      transition={{ duration: 0.8, delay: 0.1, repeat: Infinity, ease: "easeInOut" }}
    />
    <motion.div
      className={`w-2 h-2 ${theme === 'dark' ? 'bg-purple-400' : 'bg-purple-600'} rounded-full`}
      animate={{ y: [0, -3, 0] }}
      transition={{ duration: 0.8, delay: 0.2, repeat: Infinity, ease: "easeInOut" }}
    />
  </motion.div>
);

const AiChatMessage = ({ text, theme }) => {
  const [displayedText, setDisplayedText] = useState('');
  
  useEffect(() => {
    if (text) {
      let i = 0;
      setDisplayedText(''); // Reset for new messages
      const intervalId = setInterval(() => {
        setDisplayedText(prev => prev + text.charAt(i));
        i++;
        if (i >= text.length) {
          clearInterval(intervalId);
        }
      }, 30); // Adjust speed of typing
      return () => clearInterval(intervalId);
    }
  }, [text]);

  return <div className={`max-w-[80%] p-3 rounded-lg ${theme === 'dark' ? 'bg-purple-600 text-white' : 'bg-purple-500 text-white'}`}>{displayedText}</div>;
};


const AiChatbot = ({ task, onClose, initialMessages, onSendMessage, theme }) => {
  const [messages, setMessages] = useState(initialMessages || [
    { sender: 'ai', text: `Hello! I see you're planning to "${task}". Can I help you with that directly in the app?` }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isAiTyping, setIsAiTyping] = useState(false);
  const chatContainerRef = useRef(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isAiTyping]);

  const handleSend = async () => {
    if (!userInput.trim()) return;
    const userMessage = { sender: 'user', text: userInput };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setUserInput('');
    setIsAiTyping(true);

    if (onSendMessage) {
      const aiResponseText = await onSendMessage(newMessages); 
      setIsAiTyping(false);
      if (aiResponseText) {
        setMessages(prev => [...prev, { sender: 'ai', text: aiResponseText }]);
      }
    } else {
      // Default mock response
      setTimeout(() => {
        setIsAiTyping(false);
        setMessages(prev => [
          ...prev,
          { sender: 'ai', text: "That's interesting! While I can't do that specific action yet, I can help you track it or find resources. How about we mark it as 'in progress'?" }
        ]);
      }, 1500);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className={`fixed bottom-4 right-4 w-full max-w-md md:w-96 rounded-xl shadow-2xl p-4 border z-50
                  ${theme === 'dark' ? 'bg-slate-800/80 border-purple-500/50' : 'bg-white/90 border-purple-300/70'} backdrop-blur-md`}
    >
      <div className="flex justify-between items-center mb-3">
        <h3 className={`text-lg font-semibold ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>Xift AI Assistant</h3>
        <Button variant="ghost" size="icon" onClick={onClose} className={`${theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-slate-800'}`}>
          <LucideX className="h-5 w-5" />
        </Button>
      </div>
      <div ref={chatContainerRef} className={`h-64 overflow-y-auto mb-3 p-2 space-y-3 rounded-lg ${theme === 'dark' ? 'glass-effect' : 'bg-slate-50'}`}>
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.sender === 'ai' ? 'justify-start' : 'justify-end'}`}>
            {msg.sender === 'ai' ? (
              <AiChatMessage text={msg.text} theme={theme} />
            ) : (
              <div className={`max-w-[80%] p-3 rounded-lg ${theme === 'dark' ? 'bg-blue-600 text-white' : 'bg-blue-500 text-white'}`}>
                {msg.text}
              </div>
            )}
          </div>
        ))}
        {isAiTyping && (
          <div className="flex justify-start">
            <TypingIndicator theme={theme} />
          </div>
        )}
      </div>
      <div className="flex items-center space-x-2">
        <Input 
          value={userInput} 
          onChange={(e) => setUserInput(e.target.value)} 
          placeholder="Type your message..." 
          className={`flex-1 ${theme === 'dark' ? 'bg-slate-700 border-slate-600 text-white placeholder-gray-400' : 'bg-white border-slate-300 text-slate-800 placeholder-gray-500'}`}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
        />
        <Button onClick={handleSend} className={`${theme === 'dark' ? 'bg-purple-600 hover:bg-purple-700' : 'bg-purple-500 hover:bg-purple-600'} text-white`}>
          <Send className="h-5 w-5" />
        </Button>
      </div>
    </motion.div>
  );
};

export default AiChatbot;