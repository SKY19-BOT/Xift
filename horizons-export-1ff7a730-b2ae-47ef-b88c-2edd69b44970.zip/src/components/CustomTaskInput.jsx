import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Brain } from 'lucide-react';

const CustomTaskInput = ({ customTasks, onCustomTasksChange, onGenerate, isGenerating, theme }) => {
  const cardBaseClass = theme === 'dark' ? 'glass-effect' : 'bg-white/70 shadow-lg border border-slate-200';
  const textColor = theme === 'dark' ? 'text-white' : 'text-slate-800';
  const subTextColor = theme === 'dark' ? 'text-gray-400' : 'text-gray-600';
  const textareaClass = theme === 'dark' ? 'bg-transparent text-white placeholder-gray-400' : 'bg-white/50 text-slate-700 placeholder-gray-500';
  const buttonPrimaryClass = theme === 'dark' ? 'bg-gradient-to-r from-green-600 to-purple-600 hover:from-green-700 hover:to-purple-700 text-white' : 'bg-gradient-to-r from-green-500 to-purple-500 hover:from-green-600 hover:to-purple-600 text-white';

  return (
    <motion.div
      key="custom"
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      className="max-w-2xl mx-auto"
    >
      <div className="text-center mb-8">
        <h2 className={`text-3xl font-bold ${textColor} mb-4`}>Any specific tasks in mind?</h2>
        <p className={`${subTextColor}`}>Add your own tasks or let AI surprise you (optional)</p>
      </div>
      
      <div className={`${cardBaseClass} rounded-2xl p-6 mb-8`}>
        <Textarea
          value={customTasks}
          onChange={(e) => onCustomTasksChange(e.target.value)}
          placeholder="Enter your tasks, one per line...&#10;Example:&#10;Finish project report&#10;Call mom&#10;Organize desk"
          className={`w-full h-32 border-none outline-none resize-none focus-visible:ring-0 focus-visible:ring-offset-0 ${textareaClass}`}
        />
      </div>
      
      <div className="text-center">
        <Button 
          onClick={onGenerate}
          disabled={isGenerating}
          className={`${buttonPrimaryClass} px-8 py-3 text-lg`}
        >
          {isGenerating ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              AI is thinking...
            </>
          ) : (
            <>
              Generate AI Suggestions <Brain className="w-5 h-5 ml-2" />
            </>
          )}
        </Button>
      </div>
    </motion.div>
  );
};

export default CustomTaskInput;