import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TIME_OPTIONS, PART_OF_DAY_OPTIONS } from '@/constants';
import { Clock, Sparkles } from 'lucide-react';

const TimeSelection = ({ selectedTime, customTimeInput, selectedPartOfDay, onTimeSelect, onCustomTimeInput, onPartOfDaySelect, onNext, onSkip, theme }) => {
  const cardBaseClass = theme === 'dark' ? 'glass-effect' : 'bg-white/70 shadow-lg border border-slate-200';
  const cardHoverClass = theme === 'dark' ? 'hover:bg-white/20' : 'hover:bg-slate-50';
  const ringClass = theme === 'dark' ? 'ring-blue-400 pulse-glow' : 'ring-blue-500'; // Adjusted pulse-glow for blue
  const textColor = theme === 'dark' ? 'text-white' : 'text-slate-800';
  const subTextColor = theme === 'dark' ? 'text-gray-400' : 'text-gray-600';
  const inputClass = theme === 'dark' ? 'bg-slate-700/50 border-slate-600/50 text-white placeholder-gray-400' : 'bg-white border-slate-300 text-slate-700 placeholder-gray-500';
  const selectTriggerClass = theme === 'dark' ? 'glass-effect text-white hover:bg-white/20 data-[state=open]:ring-2 data-[state=open]:ring-blue-400' : 'bg-white text-slate-800 border-slate-300 hover:bg-slate-50 data-[state=open]:ring-2 data-[state=open]:ring-blue-500';
  const selectContentClass = theme === 'dark' ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-800';
  const selectItemClass = theme === 'dark' ? 'hover:bg-purple-600 focus:bg-purple-600 data-[state=checked]:bg-purple-500' : 'hover:bg-purple-100 focus:bg-purple-100 data-[state=checked]:bg-purple-200';
  const buttonPrimaryClass = theme === 'dark' ? 'bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white' : 'bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white';
  const buttonOutlineClass = theme === 'dark' ? 'border-white/30 text-white hover:bg-white/10' : 'border-slate-400 text-slate-700 hover:bg-slate-100';

  return (
    <motion.div
      key="time"
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      className="max-w-3xl mx-auto"
    >
      <div className="text-center mb-8">
        <h2 className={`text-3xl font-bold ${textColor} mb-4`}>How much time do you have?</h2>
        <p className={`${subTextColor}`}>And which part of the day is it?</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div>
            <h3 className={`text-xl font-semibold ${textColor} mb-3 text-center`}>Available Time</h3>
            <div className="grid grid-cols-2 gap-4">
                {TIME_OPTIONS.map((time) => (
                  <motion.button
                    key={time.id}
                    whileHover={{ scale: 1.03, y: -5 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => onTimeSelect(time.id)}
                    className={`p-6 rounded-2xl transition-all duration-300 text-center ${cardBaseClass} ${
                      selectedTime === time.id && !customTimeInput ? `ring-4 ${ringClass}` : cardHoverClass
                    }`}
                  >
                    <Clock className={`w-8 h-8 mx-auto mb-3 ${textColor}`} />
                    <h3 className={`text-lg font-semibold ${textColor}`}>{time.label}</h3>
                  </motion.button>
                ))}
            </div>
            <div className="mt-4">
                <Input 
                    type="number"
                    min="1"
                    placeholder="Or enter custom time in minutes..."
                    value={customTimeInput}
                    onChange={(e) => onCustomTimeInput(e.target.value)}
                    onFocus={() => onTimeSelect(null)} 
                    className={`${inputClass} w-full ${customTimeInput ? (theme === 'dark' ? 'ring-2 ring-blue-400' : 'ring-2 ring-blue-500') : ''}`}
                 />
            </div>
        </div>
        <div>
            <h3 className={`text-xl font-semibold ${textColor} mb-3 text-center`}>Part of Day</h3>
            <Select onValueChange={(value) => onPartOfDaySelect(value)} value={selectedPartOfDay || ""}>
              <SelectTrigger className={`w-full ${selectTriggerClass}`}>
                <SelectValue placeholder="Select part of day" />
              </SelectTrigger>
              <SelectContent className={selectContentClass}>
                {PART_OF_DAY_OPTIONS.map(option => (
                  <SelectItem key={option.id} value={option.id} className={selectItemClass}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
        </div>
      </div>
      
      {((selectedTime || (customTimeInput.trim() && parseInt(customTimeInput) > 0)) && selectedPartOfDay) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <Button 
            onClick={onNext}
            className={`${buttonPrimaryClass} px-8 py-3 text-lg mr-4`}
          >
            Next: Add Tasks <Sparkles className="w-5 h-5 ml-2" />
          </Button>
          <Button 
            onClick={onSkip}
            variant="outline"
            className={buttonOutlineClass}
          >
            Skip & Generate
          </Button>
        </motion.div>
      )}
    </motion.div>
  );
};

export default TimeSelection;