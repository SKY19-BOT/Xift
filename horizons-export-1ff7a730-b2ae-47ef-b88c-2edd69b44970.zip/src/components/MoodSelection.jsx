import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MOODS } from '@/constants';
import { SmilePlus, Mic, Clock, Sun, Target, Zap, Moon, Coffee } from 'lucide-react';

const iconComponents = { Sun, Target, Zap, Moon, Coffee };

const MoodSelection = ({ selectedMood, customMoodInput, voiceTranscript, isListening, onMoodSelect, onCustomMoodInput, onListen, onNext, theme }) => {
  const cardBaseClass = theme === 'dark' ? 'glass-effect' : 'bg-white/70 shadow-lg border border-slate-200';
  const cardHoverClass = theme === 'dark' ? 'hover:bg-white/20' : 'hover:bg-slate-50';
  const ringClass = theme === 'dark' ? 'ring-purple-400 pulse-glow' : 'ring-purple-500';
  const textColor = theme === 'dark' ? 'text-white' : 'text-slate-800';
  const subTextColor = theme === 'dark' ? 'text-gray-400' : 'text-gray-600';
  const inputClass = theme === 'dark' ? 'bg-slate-700/50 border-slate-600/50 text-white placeholder-gray-400' : 'bg-white border-slate-300 text-slate-700 placeholder-gray-500';
  const buttonOutlineClass = theme === 'dark' ? 'border-white/30 text-white hover:bg-white/10' : 'border-slate-400 text-slate-700 hover:bg-slate-100';
  const buttonPrimaryClass = theme === 'dark' ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white' : 'bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white';


  return (
    <motion.div
      key="mood"
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      className="max-w-4xl mx-auto"
    >
      <div className="text-center mb-8">
        <h2 className={`text-3xl font-bold ${textColor} mb-4`}>How are you feeling right now?</h2>
        <p className={`${subTextColor}`}>Your mood helps me suggest the perfect activities</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {MOODS.map((mood) => {
          const IconComponent = iconComponents[mood.icon];
          return (
            <motion.button
              key={mood.id}
              whileHover={{ scale: 1.03, y: -5 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => onMoodSelect(mood.id)}
              className={`p-6 rounded-2xl transition-all duration-300 ${cardBaseClass} ${
                selectedMood === mood.id && selectedMood !== 'custom' ? `ring-4 ${ringClass}` : cardHoverClass
              }`}
            >
              <div className="text-center">
                <div className="text-4xl mb-2">{mood.emoji}</div>
                {IconComponent && <IconComponent className={`w-8 h-8 mx-auto mb-3 ${textColor}`} />}
                <h3 className={`text-lg font-semibold ${textColor}`}>{mood.label}</h3>
              </div>
            </motion.button>
          );
        })}
        <motion.div
          whileHover={{ scale: 1.03, y: -5 }}
          className={`p-6 rounded-2xl transition-all duration-300 flex flex-col items-center justify-center space-y-3 ${cardBaseClass} ${
            selectedMood === 'custom' ? `ring-4 ${ringClass}` : cardHoverClass
          }`}
        >
          <SmilePlus className={`w-8 h-8 ${textColor}`} />
          <h3 className={`text-lg font-semibold ${textColor} text-center`}>Something Else?</h3>
          <Input 
            type="text" 
            placeholder="Type your mood..." 
            value={customMoodInput}
            onChange={(e) => onCustomMoodInput(e.target.value)}
            onFocus={() => onMoodSelect('custom')}
            className={`${inputClass} w-full`}
          />
          <Button onClick={onListen} variant="outline" className={`w-full ${buttonOutlineClass}`}>
            <Mic className={`w-4 h-4 mr-2 ${isListening ? 'text-red-500 animate-pulse' : ''}`} />
            {isListening ? 'Listening...' : 'Voice Input'}
          </Button>
        </motion.div>
      </div>

      {isListening && voiceTranscript && (
        <motion.div 
          initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}}
          className={`p-3 mb-4 rounded-md text-sm text-center ${theme === 'dark' ? 'bg-slate-700 text-gray-300' : 'bg-slate-200 text-slate-700'}`}
        >
          Recognized: "<em>{voiceTranscript}</em>"
        </motion.div>
      )}
      
      {(selectedMood && (selectedMood !== 'custom' || customMoodInput.trim())) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <Button 
            onClick={onNext}
            className={`${buttonPrimaryClass} px-8 py-3 text-lg`}
          >
            Next: Choose Time <Clock className="w-5 h-5 ml-2" />
          </Button>
        </motion.div>
      )}
    </motion.div>
  );
};

export default MoodSelection;